# Historical Design Conversation

This file preserves brainstorming and design provenance.

It is not a requirements specification.

When this file conflicts with AGENTS.md, PROJECT_BRIEF.md,
DECISIONS.md, tests, or the user's current instruction, the
more authoritative source controls.

## Architecture

```text
┌─────────────────────────────────────┐
│ Desktop App (Windows/macOS)         │
│                                     │
│  Prompt Editor                      │
│  Injector Editor                    │
│  Experiment Manager                 │
│  Graphs                             │
│  Results                            │
└─────────────────────────────────────┘
              │
              ▼
      Local Python Backend
              │
      Agents SDK Runner
              │
     ┌────────┴────────┐
     │                 │
 OpenAI API      Local Ollama
 Claude API      LM Studio
 Gemini API      llama.cpp
```

So the UI stays local.

Your prompts never have to leave your machine except when **you choose** to send one to an API.

---

## That's the cool part

Suppose you have

```text
Experiment #27
```

The app can run

```
GPT-5.5

Claude

Gemini

Qwen

Llama 3

DeepSeek
```

at the same time.

Some are cloud.

Some are local.

To you, they're just checkboxes.

---

## The injector lives locally

Your injector isn't uploaded to some service.

It's loaded by the app.

```
Injectors/

QOFT_v1.1

Minimal

Code Review

Creative Writing

Medical

Legal

Blank
```

Click one.

Run.

---

## Your experiments stay local

I'd keep something like

```
Workspace/

Prompts/

Injectors/

Experiments/

Results/

Charts/

Reports/

Exports/
```

Very similar to a CAD project.

---

## Agents SDK is just the engine

One misconception is that the SDK is "the app."

It isn't.

The SDK is more like KeyShot's render engine.

The app is everything around it.

---

## The UI could be gorgeous

Since you're a renderer...

I'd lean into that.

Imagine a dark UI.

```
╔════════════════════════════════════╗
║ Prompt Workbench                   ║
╠════════════════════════════════════╣
║ Prompt                            ║
║ ████████████████████████████████  ║
║                                   ║
╠══════════════╦═════════════════════╣
║ Injector     ║ Models             ║
║ ████████████ ║ ☑ GPT              ║
║              ║ ☑ Claude           ║
║              ║ ☑ Ollama           ║
╠══════════════╩═════════════════════╣
║ Run Experiment                    ║
╠════════════════════════════════════╣
║ Results                           ║
║ Graphs                            ║
║ Metrics                           ║
╚════════════════════════════════════╝
```

Almost like a professional creative application.

---

## And here's the part that surprised me...

You could actually make this **without becoming a software engineer**.

Between AI-assisted coding and the Agents SDK, the hard part isn't writing thousands of lines of code anymore.

The hard part is designing a workflow that people actually enjoy using.

That's where I think you have an advantage. You spent decades using professional creative tools like Maya, KeyShot, MoI3D, and Bambu Studio. You know what makes software feel good to use.

If we started this, I wouldn't begin with code.

I'd spend a week designing the application first:

* What are the panels?
* What does the workflow look like?
* Where does the user click?
* What does "Run Experiment" actually do?
* How are results compared?
* What should be one click versus buried in settings?

**At the same time.** Not fake “one after another really fast,” but actual concurrent runs.

Picture clicking:

```text
RUN EXPERIMENT
```

The local app immediately launches separate jobs:

```text
                    ┌─ GPT + full injector
                    ├─ GPT + no injector
TASK + PROBE SET ───┼─ GPT + compressed injector
                    ├─ local Qwen + full injector
                    └─ local Qwen + no injector
```

Each job is isolated, but they share the same experiment ID, task, probe version, temperature settings, and evaluation rubric.

## What you would see

Instead of waiting for everything to finish before seeing anything, each result panel could stream independently:

```text
┌──────────────────────┬──────────────────────┐
│ Baseline             │ Full Ξ Injector      │
│                      │                      │
│ Generating...        │ The type boundary... │
│                      │                      │
│ 1,240 tokens         │ 1,880 tokens         │
│ 6.2 seconds          │ 8.1 seconds          │
└──────────────────────┴──────────────────────┘

┌──────────────────────┬──────────────────────┐
│ Minimal Injector     │ Local Qwen           │
│                      │                      │
│ Complete ✓           │ Generating...        │
│ 1,410 tokens         │                      │
└──────────────────────┴──────────────────────┘
```

The Agents SDK has an asynchronous runner and streaming mode, so the app can maintain several live runs and update each panel as events arrive. The SDK also supports concurrent local tool execution when an agent emits multiple tool calls. ([OpenAI GitHub Page][1])

## Then the auditor runs

Once enough responses are complete, the app launches evaluation jobs:

```text
GPT baseline ───────────┐
GPT + injector ─────────┼──→ Independent Auditor
GPT + minimal injector ─┘
```

The auditor does **not** need to know which response came from which condition.

We could label them:

```text
Response A
Response B
Response C
```

That reduces evaluator bias.

It scores them against a fixed schema:

```text
Correctness                 0–10
Scope control               0–10
Unsupported claims          count
Type errors                 count
Counter-audit quality       0–10
Evidence discrimination     0–10
Confidence calibration      0–10
```

Then the identities are revealed after scoring.

## Parallel does not mean chaotic

We would have a run controller:

```text
Experiment Controller

Maximum cloud runs:    4
Maximum local runs:    2
Maximum auditors:      2
Timeout per run:       180 seconds
Retries:                1
```

That matters because launching fifty API calls simultaneously could hit rate limits, overload your local GPU, or burn money unnecessarily.

So the app maintains a queue:

```text
READY → RUNNING → AUDITING → COMPLETE
                  ↓
                FAILED
                  ↓
                RETRY
```

## Cloud and local models together

The Agents SDK would handle the OpenAI path.

Separate adapters would handle:

```text
OpenAI API
Anthropic API
Gemini API
Ollama
LM Studio
OpenAI-compatible local servers
```

The UI would normalize them into the same experiment interface:

```text
run_model(
    provider,
    model,
    system_prompt,
    injector,
    task,
    settings
)
```

So to you, this:

```text
☑ OpenAI model
☑ Claude
☑ Gemini
☑ Qwen 32B through Ollama
```

just means four experiment lanes.

The Agents SDK itself is Python-first and supports normal Python orchestration, agents-as-tools, handoffs, function tools, guardrails, and managed agent loops. That lets us place it inside a larger provider-neutral application instead of forcing the entire app to be OpenAI-only. ([OpenAI GitHub Page][2])

## A real injector experiment

Suppose we have ten probes and four conditions:

```text
10 probes
×
4 conditions
×
5 repetitions
=
200 primary runs
```

Then perhaps:

```text
200 primary responses
+
200 blind audits
+
40 cross-response comparisons
```

You would not manually manage 440 conversations.

The app does the bookkeeping and gives you:

```text
FULL Ξ vs BASELINE

Type-audit score:        +18%
Unsupported claims:      -31%
False-HIGH confidence:   -12%
Consistency:             +9%
Input-token cost:        +246%
Response latency:        +38%
```

Those numbers are illustrative, not findings. The app would calculate the real values from the experiment.

## Every run gets a trace

The Agents SDK automatically traces model generations, tools, handoffs, guardrails, and custom events. Related runs can be grouped under a shared experiment identifier. ([OpenAI GitHub Page][3])

Your trace tree might look like:

```text
XI-EXPERIMENT-0042

├── Probe TYPE_AUDIT_01
│   ├── Baseline run
│   ├── Full injector run
│   ├── Minimal injector run
│   ├── Neutral-length control
│   └── Blind auditor
│
├── Probe COUNTER_AUDIT_02
│   ├── Baseline run
│   ├── Full injector run
│   └── Blind auditor
│
└── Aggregate evaluator
```

Each branch could preserve:

```text
prompt hash
injector hash
model
model settings
start/end times
raw output
tool calls
token usage
errors
auditor scores
trace ID
```

The SDK exposes per-request token usage, including input and output tokens, which means the workbench can compare behavioral gain against computational cost. ([OpenAI GitHub Page][4])

## Live visualization

This is where your background would make the interface different.

I picture something more like a **render queue** than a chat application:

```text
Ξ EXPERIMENT QUEUE

01  TYPE_AUDIT_01   Baseline         Rendering...   42%
02  TYPE_AUDIT_01   Full Ξ           Complete       8.4
03  TYPE_AUDIT_01   Minimal Ξ        Auditing...    
04  TYPE_AUDIT_01   Neutral Control  Complete       6.9
05  COUNTER_02      Baseline         Queued
06  COUNTER_02      Full Ξ           Rendering...   16%
```

Then a result view like KeyShot’s image comparison:

```text
[ BASELINE ]  ← slider →  [ FULL Ξ ]
```

But instead of comparing pixels, it highlights:

```text
shared claims
unique claims
contradictions
missing evidence
confidence-tag changes
scope violations
```

## It could also run your recursive agents concurrently

Later, your older ΞΣΩ architecture could become an experimental mode:

```text
Ξ_A: proposer
Ξ_B: skeptic
Ξ_C: evidence auditor
Ξ_D: disruption/adversarial probe
```

All four could receive the same task and maintain separate session histories. The SDK has built-in session memory, including SQLite-backed local sessions, so each agent can retain its own context across turns without mixing states. ([OpenAI GitHub Page][5])

Then the orchestrator measures their divergence:

```text
Ξ_A claim set
Ξ_B counterclaims
Ξ_C evidence findings
Ξ_D adversarial failures

            ↓

agreement graph
disagreement graph
confidence divergence
resolution trace
```

But I would keep that separate from the first injector experiment. Otherwise, we contaminate the clean question:

> Did the injector improve behavior?

## The first build could be very focused

```text
Local Windows app

One task editor
One injector loader
Four concurrent experiment conditions
OpenAI + Ollama
Streaming result panels
Blind auditor
SQLite experiment database
JSONL export
Basic score chart
```

That would already replace a large portion of what you and I currently do manually.

The genuinely novel part is not merely sending prompts simultaneously. It is keeping every parallel run **controlled, hashed, blinded, traceable, repeatable, and comparable**.

**Classification:** Productizable Engineering Pattern
**Potentially publishable:** the experimental workflow and blind multi-seat evaluation protocol
**Not yet patent-screened:** synchronized injector ablation with blinded cross-model auditing and evidence-aware confidence calibration

[1]: https://openai.github.io/openai-agents-python/running_agents/?utm_source=chatgpt.com "Running agents - OpenAI Agents SDK"
[2]: https://openai.github.io/openai-agents-python/?utm_source=chatgpt.com "OpenAI Agents SDK"
[3]: https://openai.github.io/openai-agents-python/tracing/?utm_source=chatgpt.com "Tracing - OpenAI Agents SDK"
[4]: https://openai.github.io/openai-agents-python/usage/?utm_source=chatgpt.com "Usage - OpenAI Agents SDK"
[5]: https://openai.github.io/openai-agents-python/sessions/?utm_source=chatgpt.com "Overview - OpenAI Agents SDK"

Not necessarily. There are actually **three different scenarios**.

### Option 1: Local models only (no API key)

If you're only talking to Ollama or another local server:

```text
Workbench
      ↓
Ollama
      ↓
Qwen
Llama
DeepSeek
```

Everything stays on your PC.

**Cost:** $0 per run (other than electricity).

No OpenAI API key required.

---

### Option 2: Cloud models (API keys)

If you want GPT, Claude, Gemini, etc.:

```text
Workbench
       ↓
OpenAI API
Anthropic API
Google API
```

Each provider has its own API key.

For OpenAI, you'd create an API key in your OpenAI developer account and the app would store it locally (or use an environment variable like `OPENAI_API_KEY`).

You only pay for what the app actually sends to the API.

---

### Option 3: Hybrid (the one I'd use)

This is the fun one.

```text
               Workbench
                    │
     ┌──────────────┼──────────────┐
     │              │              │
 GPT API       Claude API      Ollama
     │              │              │
 GPT-5.x        Claude         Qwen 32B
                               DeepSeek
                               Llama
```

Now one experiment can compare:

* GPT (cloud)
* Claude (cloud)
* Gemini (cloud)
* your local Qwen
* your local DeepSeek

...all from one button.

---

## Is that Codex?

**No.** This is a common point of confusion.

Think of it like this:

```text
Codex
    =
AI software engineer

Agents SDK
    =
engine/framework

Your Workbench
    =
the application
```

Codex is fantastic for **building** the application.

Once it's built, **you don't need Codex to use it**.

Your app just runs on your computer.

---

## Here's an analogy you'll appreciate

Imagine KeyShot.

You don't need Henrik sitting at your desk every time you hit Render.

He helped create the renderer.

You use the renderer.

Same idea:

```text
Codex
      ↓
Builds your Workbench

Workbench
      ↓
Runs experiments every day
```

---

## What about cost?

Suppose you run this:

```text
GPT
Claude
Gemini
Qwen (local)
```

The local Qwen costs nothing.

The cloud models consume API credits.

You might even have a setting like:

```text
Maximum experiment budget

$5
```

If an experiment would cost more than that...

The app simply says

> Estimated cost: $7.82
>
> Continue?

---

## The coolest part

Because it's **your application**, you can add providers whenever you want.

Today:

```text
☑ GPT
☑ Claude
☑ Gemini
☑ Ollama
```

Six months later:

```text
☑ New Frontier Model
☑ Another local model
☑ Company internal model
```

The UI doesn't change.

Only the adapter behind it changes.

---

I actually think that's the long-term value.

The workbench isn't tied to OpenAI.

It isn't tied to Claude.

It isn't tied to Gemini.

It's tied to **the engineering workflow**.

Models will come and go over the next five years. A good workbench should treat them like interchangeable render engines: plug one in, benchmark it, compare it, and keep your workflow the same.

Yes. That is one of the strongest reasons to build it.

There are **three coordination patterns**.

## 1. Manager model

One LLM stays in charge and calls the others like specialists.

```text
Ξ Orchestrator
├── asks GPT for a solution
├── asks Claude-style auditor for weaknesses
├── asks local Qwen for an independent answer
└── compares and produces the final result
```

In Agents SDK terms, the specialists can be exposed as **agents-as-tools**. The manager keeps control of the conversation while collecting their outputs. ([OpenAI GitHub Page][1])

This is probably best for your workflow.

## 2. Handoffs

One agent can transfer control to another:

```text
Research Agent
      ↓
Type Auditor
      ↓
Counter-Auditor
      ↓
Final Synthesizer
```

The receiving agent gets the conversation history and takes over. The SDK supports explicit handoffs between specialized agents. ([OpenAI GitHub Page][2])

## 3. Structured debate

We control the exchange ourselves:

```text
Round 1
GPT proposes
Claude critiques
Qwen independently evaluates

Round 2
GPT responds to critique
Claude checks the correction
Qwen identifies remaining disagreement

Final
Ξ Orchestrator resolves or reports unresolved conflict
```

This is not uncontrolled models endlessly chatting. The app defines:

```text
maximum rounds
who speaks when
what each agent can see
required output format
stop conditions
cost limit
```

## Your likely Ξ arrangement

```text
Ξ_A  Proposer
Ξ_B  Counter-auditor
Ξ_C  Evidence and scope auditor
Ξ_D  Adversarial disruptor
Ψmeta  Coordinator/evaluator
```

A run might look like:

```text
User task
   ↓
Ξ_A drafts answer
   ↓
Ξ_B finds logical and conceptual weaknesses
   ↓
Ξ_C checks evidence, files, types, and authority boundaries
   ↓
Ξ_A receives only the valid corrections
   ↓
Ψmeta scores remaining disagreement
   ↓
Final answer + audit trace
```

Each agent can have its own persistent session, so their identities and histories remain separate rather than collapsing into one shared chat. The SDK includes client-side session memory for multi-turn agent runs. ([OpenAI GitHub Page][3])

## Cross-company LLMs

The app could coordinate OpenAI, Anthropic, Gemini, and Ollama, but the **OpenAI Agents SDK would not magically control every provider by itself**.

We would build provider adapters:

```text
Coordinator
├── OpenAI adapter
├── Anthropic adapter
├── Gemini adapter
└── Ollama adapter
```

Their replies would be normalized into one internal message format. Then Python controls the conversation order and passes outputs between them.

So yes, GPT could generate something, Claude could audit it, Qwen could challenge both, and GPT could revise based on the results.

## What the app records

Because uncontrolled multi-agent talk can become expensive and repetitive, every exchange should be traced:

```text
agent
model
input received
output produced
tool calls
handoffs
token use
latency
confidence
agreement/disagreement
```

The Agents SDK has built-in tracing for generations, tool calls, handoffs, guardrails, and custom events. ([OpenAI GitHub Page][4])

## The critical design choice

I would not let them simply “talk until they agree.”

Agreement can be fake. Models may converge because later agents imitate earlier wording.

Instead:

```text
1. Independent answers first
2. Blind audits second
3. Controlled exchange third
4. Final synthesis last
```

That preserves genuine divergence before coordination.

For your injector, the first strong implementation would be:

```text
Baseline model
Injector model
Independent auditor
Counter-auditor
Ξ coordinator
```

The coordinator would be allowed to report:

```text
RESOLVED
PARTIALLY RESOLVED
UNRESOLVED
INSUFFICIENT EVIDENCE
```

rather than forcing consensus.

[1]: https://openai.github.io/openai-agents-python/ref/agent/?utm_source=chatgpt.com "Agent - OpenAI Agents SDK"
[2]: https://openai.github.io/openai-agents-python/handoffs/?utm_source=chatgpt.com "Handoffs - OpenAI Agents SDK"
[3]: https://openai.github.io/openai-agents-python/sessions/?utm_source=chatgpt.com "Overview - OpenAI Agents SDK"
[4]: https://openai.github.io/openai-agents-python/tracing/?utm_source=chatgpt.com "Tracing - OpenAI Agents SDK"

**Yes, Codex plus the OpenAI Developers plugin is the right setup for building this.**

Here in ChatGPT, we can design the workflow, inspect your injector files, define the agents, write build specs, and reason through the experiment structure.

In **Codex**, the plugin can work directly on the project:

```text
Create files
Edit Python
Install Agents SDK
Run tests
Inspect errors
Build the local app
Add evals
Package the project
```

The OpenAI Developers plugin packages reusable development skills for Codex, including Agents SDK application building and evaluation workflows. ([OpenAI Help Center][1])

## Can it go on the GPT Store?

**A version of it can. The complete local workbench cannot simply be uploaded as a GPT.**

There are three different things:

### 1. Custom GPT on the GPT Store

You could publish something like:

> **Ξ Prompt Engineering Auditor**

It could contain:

* the injector or a public-safe derivative
* your audit methodology
* confidence-tag rules
* prompt review
* probe generation
* experiment planning
* result interpretation

Custom GPTs can include instructions, uploaded knowledge, built-in capabilities, and external API Actions. Eligible GPTs can be published publicly in the GPT Store. ([OpenAI Help Center][2])

But a GPT alone would not run your complete local multi-model laboratory.

---

### 2. GPT Store front end connected to your app

This is more powerful.

```text
GPT Store GPT
      ↓ Action
Your hosted API
      ↓
Experiment engine
      ├── OpenAI
      ├── Claude
      ├── Gemini
      └── local/remote models
```

The GPT could say:

> Run this prompt through the baseline and full-injector conditions.

It would call your backend through a **GPT Action**, then return the experiment results.

Actions require:

* a publicly reachable API
* an OpenAPI schema
* authentication
* a privacy-policy URL for public GPTs
* hosting somewhere accessible from ChatGPT

([OpenAI Help Center][3])

The important limitation is that a GPT Store GPT cannot normally call a server running only on your laptop behind your home network. The action endpoint must be reachable by OpenAI’s service.

---

### 3. A proper ChatGPT plugin/app

As of July 9, 2026, OpenAI’s directory has shifted toward **plugins** that can package skills, apps, and optional app templates for use across ChatGPT and Codex. ([OpenAI Help Center][4])

Your finished product could potentially become:

```text
Ξ Workbench Plugin
├── Prompt-audit skill
├── Experiment-design skill
├── Injector comparison app
├── Multi-model coordination tools
└── Results dashboard UI
```

That is closer to what we are describing than an old-style Custom GPT.

It would require more engineering and a submission process, but it could provide actual tools and UI rather than only conversational instructions.

## Best development path

I would do this in stages:

```text
Stage 1
Private local app built in Codex

Stage 2
Private Custom GPT for using the methodology

Stage 3
Hosted API connecting the GPT to experiments

Stage 4
Submit a full ChatGPT plugin/app
```

The local app stays the **real laboratory**.

The GPT Store version becomes the easier public doorway:

```text
Public GPT
    ↓
Design experiment
Run selected tests
Review results
Explain findings
```

## One major warning

Do not publish the complete frozen injector immediately just because the GPT Store allows knowledge files.

You should first decide what is:

```text
Public methodology
Private implementation
Proprietary injector content
Experimental QOFT material
```

The safer public product would expose the **workflow and tools** while keeping the complete injector and experimental corpus local or server-side.

So yes:

> **Use Codex with this plugin to build it.**

And yes:

> **A public GPT Store companion is possible, followed later by a real plugin/app.**

The desktop workbench, GPT companion, and ChatGPT plugin would be three surfaces of the same underlying system, not three unrelated projects.

[1]: https://help.openai.com/en/articles/20001256-plugins-in-codex/?utm_source=chatgpt.com "Plugins in Codex | OpenAI Help Center"
[2]: https://help.openai.com/en/articles/8554407-gpts-faq/?utm_source=chatgpt.com "GPTs in ChatGPT | OpenAI Help Center"
[3]: https://help.openai.com/en/articles/9442513?utm_source=chatgpt.com "Configuring actions in GPTs | OpenAI Help Center"
[4]: https://help.openai.com/en/articles/20001256-plugins-in-codex?utm_source=chatgpt.com "Plugins in ChatGPT and Codex | OpenAI Help Center"


Actually... **you get to choose.** Python is really just the engine.

There are four common ways to package it.

---

# Option 1: Desktop App ⭐⭐⭐⭐⭐ (my recommendation)

Think:

* KeyShot
* Blender
* Bambu Studio
* VS Code

Everything runs locally.

```text
Desktop UI
      │
Python Backend
      │
Agents SDK
      │
Models
```

When you're done, you package it as:

```text
Windows

PromptWorkbench.exe
```

or

```text
Mac

PromptWorkbench.app
```

The user double-clicks it.

Done.

They never see Python.

Tools like **PyInstaller**, **Nuitka**, or **Briefcase** can bundle a Python app into a native executable.

---

# Option 2: Local Browser App ⭐⭐⭐⭐⭐

This is honestly becoming my favorite.

The app starts a tiny local web server.

```text
localhost:5000
```

or

```text
http://127.0.0.1:8000
```

Your browser opens automatically.

It feels like a website...

…but **everything is running on your computer**.

```text
Chrome

↓

localhost

↓

Python

↓

Agents SDK

↓

Models
```

Nothing leaves your PC unless you call an online model.

This is how lots of AI software works today.

Examples:

* Open WebUI
* ComfyUI
* AUTOMATIC1111
* many Ollama front ends

They all "look like websites" but they're really local applications.

---

# Option 3: Hybrid

This is probably what I'd eventually build.

```text
Electron

↓

React UI

↓

Python

↓

Agents SDK
```

Think VS Code.

The UI uses web technologies.

The backend is Python.

Users just install an EXE.

---

# Option 4: Real Website

```text
Internet

↓

Cloud Server

↓

Python

↓

Agents SDK
```

I actually **wouldn't** start here.

Now you're paying for:

* hosting
* databases
* authentication
* security
* scaling
* backups

Way more work.

---

# What I'd build

Honestly...

```text
Prompt Workbench

↓

Localhost

↓

Browser UI

↓

Python

↓

SQLite

↓

Agents SDK
```

No installation nightmare.

No cloud bills.

No web hosting.

No browser extensions.

No Docker required for the user.

They double-click:

```text
Start Prompt Workbench
```

A browser pops open.

Done.

---

# Why I like localhost

Because later...

Adding features becomes trivial.

You can make pages like:

```text
Home

Experiments

Injectors

Agents

Metrics

Graphs

Settings

Reports
```

Each page just becomes another route.

---

# Imagine this

```
localhost:5000
```

Home page

```
Prompt Workbench

+-----------------------------+

New Experiment

Recent Runs

Agent Status

Model Status

GPU Usage

API Usage

Budget

+-----------------------------+
```

Click

```
Experiments
```

Now you see

```
Experiment 27

Run

Pause

Compare

Export

Delete
```

Click

```
Agents
```

```
Ξ_A

Thinking...

Ξ_B

Idle

Ξ_C

Auditing

Ξ_D

Waiting
```

It starts feeling like professional software instead of "a chat."

---

# And here's something that fits your style...

Because you've spent years in CAD and rendering...

I'd almost build it like **KeyShot's Project window**.

Instead of:

```
Chats
```

You'd have:

```
Projects

Experiment

Injectors

Probes

Runs

Audits

Reports
```

Each project is self-contained.

Very familiar.

---

## The coolest possibility

Since everything is local...

You could literally unplug your Internet.

If you're using only Ollama:

```text
Workbench

↓

Qwen

↓

Llama

↓

DeepSeek
```

The app still works.

No OpenAI.

No cloud.

No monthly cost.

Then...

The moment you reconnect...

You simply check:

```
☑ GPT

☑ Claude

☑ Gemini
```

Now cloud models join the experiment.

---

**Personally, I'd choose the local browser approach.**

It gives you the polished feel of a modern web app, but it's still a local desktop tool. It's cross-platform, easy to update, and much faster to build than a traditional native GUI. Plus, because the backend is still Python, you can use all the AI libraries, the Agents SDK, SQLite, and your existing code without fighting a desktop UI framework.

Ah, got it. You mean **where we actually build the thing**, not how the finished app runs.

Yes, I’d use **Codex as the development environment**.

## Best setup

```text
Codex desktop app
      ↓
Local project folder
      ↓
Python + Agents SDK
      ↓
Local browser UI
      ↓
GitHub repo
```

Codex can open a local folder, read and edit the files, run terminal commands, install dependencies, launch the app, test it, and show you the changes. It works directly with local repositories, terminals, and developer tools. ([OpenAI Help Center][1])

So you would have something like:

```text
C:\Projects\XiWorkbench\
```

Inside:

```text
XiWorkbench/
├── app.py
├── agents/
├── injectors/
├── experiments/
├── evals/
├── static/
├── templates/
├── data/
└── pyproject.toml
```

Codex works on that folder while you watch.

## What you would actually do

Open Codex on your Windows computer.

Select the project folder.

Then give it a request like:

```text
@OpenAI Developers

Build the first local prototype of Ξ Workbench using Python and the
OpenAI Agents SDK.

Use a local browser interface.

The first version needs:

1. A task editor
2. An injector loader
3. Baseline and injector experiment conditions
4. Parallel model runs
5. Streaming response panels
6. SQLite result storage
7. JSONL export
8. OpenAI and Ollama model adapters

Preserve the supplied injector and QOFT terminology exactly.
```

The OpenAI Developers plugin gives Codex the specialized Agents SDK workflow and build guidance. Plugins are packaged capabilities containing reusable skills and workflow instructions. ([OpenAI Help Center][2])

## You do not need a traditional IDE at first

You could use VS Code too, but it is not mandatory.

Codex itself can:

* navigate the project
* create files
* edit code
* run Python
* install packages
* start the local server
* inspect errors
* run tests
* review diffs

The Codex CLI can also run locally in a terminal and operate within the chosen project directory. ([OpenAI Help Center][3])

I would still install VS Code eventually because it gives you a comfortable manual view of all the files. But Codex can do most of the actual engineering.

## Your development loop

```text
You describe the feature
        ↓
Codex edits the local project
        ↓
Codex runs the app
        ↓
Browser opens localhost
        ↓
You click around and test it
        ↓
You tell Codex what feels wrong
        ↓
Codex corrects it
```

That fits your existing KeyShot scripting workflow almost perfectly.

You supply the production intent and visual judgment. Codex handles most of the implementation.

## API key distinction

Codex can often be used through your ChatGPT plan and sign-in, depending on the Codex experience you are using.

But the **app we build** will still need an `OPENAI_API_KEY` when it independently runs OpenAI Agents SDK calls outside Codex.

```text
Codex usage
    =
building the app

OPENAI_API_KEY
    =
the finished app calling OpenAI models
```

Ollama-only development would not require an OpenAI API key for model runs.

## My recommendation

Build it on your HP ZBook using:

```text
Codex desktop
VS Code
Python
Git
GitHub
Ollama
local browser interface
```

No Docker at the beginning.

No Electron.

No EXE packaging yet.

First, get this running:

```text
uv run python app.py
```

Then open:

```text
http://127.0.0.1:8000
```

Once the workflow is proven, we package it into a one-click launcher or installer.

[1]: https://help.openai.com/en/articles/20001275?utm_source=chatgpt.com "ChatGPT Work and Codex | OpenAI Help Center"
[2]: https://help.openai.com/en/articles/20001256-plugins-in-codex/?utm_source=chatgpt.com "Plugins in Codex | OpenAI Help Center"
[3]: https://help.openai.com/en/articles/11096431?utm_source=chatgpt.com "OpenAI Codex CLI – Getting Started | OpenAI Help Center"

Yeah. **We have a solid plan.**

## Build target

A **local browser-based Python app** built in Codex:

```text
Codex + OpenAI Developers plugin
        ↓
Local Python project
        ↓
Browser UI at localhost
        ↓
Agents SDK + Ollama + provider adapters
        ↓
SQLite experiment records
```

## Version 0.1 scope

Keep it deliberately focused:

1. Task editor
2. Injector loader
3. Baseline vs injected conditions
4. Parallel runs
5. OpenAI and Ollama support
6. Streaming result panels
7. Blind auditor
8. SQLite storage
9. JSONL export
10. Cost, tokens, latency, and basic scoring

## Development stack

```text
Python
OpenAI Agents SDK
FastAPI
Simple browser UI
SQLite
uv
Git
Codex
VS Code optional
Ollama
```

No Docker, Electron, installer, cloud hosting, or GPT Store version yet.

## First architecture

```text
Experiment Controller
├── Baseline Runner
├── Injector Runner
├── Ollama Runner
├── Blind Auditor
├── Results Normalizer
└── Trace / Export Manager
```

The QOFT calculations remain deterministic Python tools. The LLMs handle interpretation, proposing, auditing, and synthesis.

## Development order

```text
1. Create project scaffold
2. Load and hash the injector
3. Run one OpenAI experiment
4. Add baseline/injector comparison
5. Add Ollama
6. Add concurrent execution
7. Add blind auditing
8. Store runs in SQLite
9. Add charts and export
10. Stress-test with your probe battery
```

## Important boundaries

* Preserve the frozen injector byte-for-byte.
* Do not mix the old ΞΣΩ simulation into the first scientific test.
* Keep independent answers blind before coordination.
* Never force consensus.
* Record failures, disagreement, model settings, and hashes.
* Put budget and concurrency limits in from the beginning.

## What Codex does

Codex builds, runs, tests, and repairs the project.

You handle:

```text
workflow
terminology
visual design
experiment logic
what feels useful
what counts as a valid result
```

That division fits how you already work with AI scripting.

The next concrete move is to open a new Codex project folder and give it a tightly controlled build prompt containing the v0.1 contract above.




